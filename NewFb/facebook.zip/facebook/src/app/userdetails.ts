export class Userdetails {
    email : string;
    password : string;
}

