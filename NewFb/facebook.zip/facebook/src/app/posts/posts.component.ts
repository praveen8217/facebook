import { Component, OnInit, Input } from '@angular/core';
import {NewpostComponent } from '../newpost/newpost.component'

import { SignupService } from '../Shared/signup.service';
import { Router, ActivatedRoute,Params } from '@angular/router';
import { User } from '../user';

import { Post } from '../post';
import { Comments } from '../comments'


@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.css']
  
})
export class PostsComponent implements OnInit {
postarray:Post[]=[];
user:User;
userImage:any;
comment: Comments;
id:number;
userName:string;
userEmail:string;
isSuccessful: boolean = false;
currentPost: any;
comments:Comments[]=[];
commentedUser: string;
issuccess=false;
constructor(private signupservice:SignupService,private router: Router,private route: ActivatedRoute) { 
this.comment = new Comments()
this.comment.contents === '';
  }
  // @Input('userEmail') user.firstName: string;

  ngOnInit() {
    this.isSuccessful = true;
    setTimeout(() => {
      this.isSuccessful = !this.isSuccessful;
    }, 1000);
    this.getData();
    this.getPost();
  }
  getData(){
    this.userEmail = this.route.snapshot.paramMap.get("Email");
    this.signupservice.getLoggedUser(this.userEmail).subscribe(
      data => {console.log(data)
        this.user =data;
       this.userImage= this.user.image;
    
    
        this.id=this.user.id;
        this.userName=this.user.firstName
        this.userEmail=this.user.email
        console.log(this.id);
        // @Input('userEmail'), this.user.email;
      //  localStorage.setItem(this.userEmail,this.userName)
        // myProfile(){
        //   // localStorage.getItem(this.userEmail)
        //   this.signupservice.getLoggedUser(this.userEmail).subscribe(data=>{})
        // }
        this.router.navigate(["/Profile", this.userEmail]);
      }

    );
   // this.router.navigate(["/Profile", this.userEmail]);
  }
  details(){
    this.router.navigate(["/details"])
  }
  getPost(){
    this.postarray=[];
    this.signupservice.getAllPosts().subscribe(
      data=>{
        data.forEach(element => {
          let postData = new Post();
          postData.canshow = false;
          postData.id = element.id;
          postData.likesCount = element.likesCount;
          postData.postContent = element.postContent;
          postData.postedBy = element.postedBy;
          postData.postType = element.postType;
          this.postarray.push(postData);
        });
      });
  }
  
  logOut() {
    this.router.navigateByUrl("/Login");
    localStorage.removeItem('email')
  }

  doLike(postid){
  
    this.signupservice.incrementLike(postid).subscribe(
      data=>{ 
        console.log(data)
        for (let index = 0; index < this.postarray.length; index++) {
          
          if (this.postarray[index].id === postid) 
          {
            this.postarray[index].likesCount++;
           this.issuccess=true;
          
          }
        }
      
      });
    }
    unLike(postid){
  
       this.signupservice.decrementLike(postid).subscribe(
         data=>{ 
           for (let index = 0; index < this.postarray.length; index++) {
            
             if (this.postarray[index].id === postid) 
             {
               this.postarray[index].likesCount--;
               this.issuccess=false;
          
             }
           }
        });
     }
    doComment(Postid) {
      this.currentPost=Postid;
      this.postarray.filter(post=>post.id!=Postid).forEach(element=>{
        element.canshow=false;
      });
      this.postarray.find(post=>post.id==Postid).canshow=true;
      
     }
    submit() {
      debugger;
      this.comment.Postid = this.currentPost;
      this.comment.Userid=this.id;
      
     //this.comment.commentedbyUserName = this.commentedUser;
      this.signupservice.addComment(this.comment).subscribe(data => {
        this.postarray.find(post => post.id == this.currentPost).canshow = false;
        this.signupservice.getAllComments(this.currentPost).subscribe(data => {
          this.comments=data;
          this.comment.contents = "";
        });
  
      });
    }
    goBack() {
      this.postarray.find(post => post.id == this.currentPost).canshow = false;
      this.router.navigate(["/post", this.userEmail]);
    }
  

Addpost(){
  this.router.navigate(["/Newpost",  this.id,this.userEmail]);

}
 Profile(){

//  localStorage.getItem(this.userEmail)
 this.signupservice.getLoggedUser(this.userEmail)
 }

}
