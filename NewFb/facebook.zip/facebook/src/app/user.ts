export class User {
    id:number;
    firstName : string;
    lsatName : string;
    email : string;
    password : string;
    age : number;
    imagePath : string;
    gender : string;
    image : any;
}
