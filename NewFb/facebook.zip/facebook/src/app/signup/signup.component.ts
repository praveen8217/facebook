import { Component, OnInit, ViewChild } from '@angular/core';
import { User } from '../user';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { SignupService } from '../Shared/signup.service'
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  // @ViewChild('fileInput', { static: false }) fileInput;

  @ViewChild('formValue', { static: true }) createform: NgForm;

  constructor(private httpService: HttpClient, private router: Router, private signupservice: SignupService) {
    this.user = new User();
  }
  myFiles: any;

  frmData = new FormData();

  getFileDetails(e) {


    this.myFiles = e.target.files[0];
    this.frmData.append("fileUpload", this.myFiles);

  }

  ngOnInit() {
  }
  // @ViewChild('formValue', { static: false }) formValues: NgForm;
  user: User;


  validateData(): boolean {
    this.user.firstName = this.user.firstName.trim();
    this.user.lsatName = this.user.lsatName.trim();
    this.user.email = this.user.email.trim();
    this.user.password = this.user.password.trim();
    if (this.user.firstName === undefined || this.user.firstName === "") {
      alert("enter user first name");
      return false;
    }
    if (this.user.lsatName === undefined || this.user.lsatName === "") {
      alert("enter user last name");
      return false;
    }
    if (this.user.email === undefined || this.user.email === "") {
      alert("enter user email");
      return false;
    }
    else if (this.user.password === undefined || this.user.password === "") {
      alert("enter user password");
      return false;
    }
    
    else {
      return true;
    }
  }

  validateRegisteredUser(userArray: User[]) {
    if (typeof userArray.find((d => d.email.toLocaleLowerCase() === this.user.email.toLocaleLowerCase())) === "object") {
      alert("already registered.you can login by user email and password");
    }
    else {
      // this.httpService.post<any>('http://localhost:53935/UploadFiles', this.frmData).subscribe(
      //   data => {
      //  this.user.image = data;
        //  this.signupservice.post(this.user).subscribe(
           data => {
             this.router.navigateByUrl("/Login");
            // this.formValues.reset();
             }
          // );
        
        // (err: HttpErrorResponse) => {
        //   console.log(err.message);   // SHOW ERRORS IF ANY.
        // }
      

    }
  }

  register(): void {
    let isValid: boolean = this.validateData();
    if (isValid) {
      let userArray: User[] = [];
      this.signupservice.GetAll().subscribe(
        data => {
          userArray = data;
          this.validateRegisteredUser(userArray);
        });
    }
  }
  Login() {
       this.router.navigateByUrl("/Login");
    }
  }
  


