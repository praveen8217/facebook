import { Component, OnInit, ViewChild } from '@angular/core';
import { Userdetails } from '../userdetails';
import { SignupService } from '../Shared/signup.service'
import { User } from '../User';
import { Router } from '@angular/router'
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  @ViewChild('formData', { static: false }) formValues: NgForm;
  user: Userdetails;
  isSuccessful: boolean = false;
  users: User[] = [];


  constructor(private signupservice: SignupService, private router: Router) {
    this.user = new Userdetails();
  }

  ngOnInit() {

  }
  validateUser(): boolean {
    this.user.email = this.user.email.trim();
    this.user.password = this.user.password.trim();

    if (this.user.email === undefined || this.user.email === "") {
      alert("enter user email");
      return false;
    }
    else if (this.user.password === undefined || this.user.password === "") {
      alert("enter user password");
      return false;
    }
    else {
      return true;
    }
  }
  checkValidUser(userArray: User[]) {
    if (typeof userArray.find((d => d.email.toLocaleLowerCase() === this.user.email.toLocaleLowerCase() && d.password.toLocaleLowerCase() === this.user.password.toLocaleLowerCase())) === "object") {
      this.signupservice.getUser(this.user.email).subscribe(
        data => {
          this.users = data;

        }
      );
      localStorage.setItem('email',(this.user.email))
      this.router.navigate(["/Post", this.user.email]);
      this.formValues.reset();
    }
    else {

      alert("entered data is not registered one.please do check");
    }
  }

  login() {
    console.log(this.user);
     let userarray: any[] = [];
     let isvalid: Boolean = this.validateUser();
     if (isvalid) {
       this.signupservice.GetAll().subscribe(
         data => {
           userarray = data;
           this.checkValidUser(userarray);


         }

     )
     }


  }
  // register() {
  //   this.router.navigateByUrl("/signup");
  // }
}




