import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';
import {NewpostComponent } from './newpost/newpost.component'
import { PostsComponent } from './posts/posts.component';
import {ProfileComponent} from './profile/profile.component'
import { from } from 'rxjs';
import { AuthService } from './Shared/authguard.service';
import { DetailsComponent } from './details/details.component';
// import { AuthguardService } from './Shared/auth.service';
const routes: Routes = [
  { path: "", redirectTo: '/Login', pathMatch: "full" },
   { path: 'signup', component:SignupComponent},
   { path: 'Login', component:LoginComponent},
   { path: 'Newpost', component:NewpostComponent,canActivate:[AuthService]},
   { path: 'Newpost/:id/:Email', component: NewpostComponent,canActivate:[AuthService]},
    {path:'Post', component:PostsComponent},
   { path: 'Post/:Email', component: PostsComponent,canActivate:[AuthService] },
  { path:'Profile',component:ProfileComponent,canActivate:[AuthService]},
   { path: "details", component:DetailsComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
