export class Post {
    id:number;
    postedBy:string;
    postType:string;
    postContent:String;
    likesCount:number=0;
    canshow:boolean=false;
    imageContent:String
    
}
