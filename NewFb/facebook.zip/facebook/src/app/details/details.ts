export class details {
    id:number;
    firstName : string;
    lastName : string;
    email : string;
    password : string;
    repeatpassword:string;
    Date:Date;
    occupation:string
    Language:string[]=[];
    gender : string;
}
