import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { details } from './details';
import { SignupService } from '../Shared/signup.service';
import { FormsModule } from '@angular/forms';
import { DatePickerModule } from '@syncfusion/ej2-angular-calendars';
import { select } from '@syncfusion/ej2-base';
import { convertActionBinding } from '@angular/compiler/src/compiler_util/expression_converter';
import { HostListener } from '@angular/core';
import { NgbDateStruct, NgbCalendar } from '@ng-bootstrap/ng-bootstrap';






@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {
  user: details;
  occupationlist = ['student', 'profession'];
  occupation = "";
  obdateValue: Date;
  public maxDate: Date = new Date();
  //public minDate: Date = new Date("01/05/2010");
 // public dateValue: Date = new Date();
  Languagelist = [{ Language: "English" }, { Language: "Hindi" }]
  language: string;
  category: string[] = [];
  model: any;
  date: { year: number, month: number };
  da: boolean;
  currentDate: any;
  constructor(private signupservice: SignupService, private calendar: NgbCalendar) {
    this.user = new details()

  }

  ngOnInit() {

    
  }
  dateObj(currentDate) {

    this.user.Date = this.currentDate;
  }


  addDetails(user) {

    this.signupservice.Details(user).subscribe(
      Data => {
        console.log(Data);
        alert("user registered successfully")
      }
    );


  }
 
  dummy(data) {
    this.user.occupation = data;
  }
  onChange(Language: string, isChecked: boolean) {
    if (isChecked) {
      this.category.push(Language);
      this.user.Language = this.category;
      console.log(this.user.Language)
    } else {
      console.log(this.user.Language)
    }
  }


}




