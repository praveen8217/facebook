import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { User } from '../user';
import {HttpHeaders} from '@angular/common/http';
import { Post } from '../post';
import { Observable, from } from 'rxjs';
import {Comments} from '../comments'
import { details } from '../details/details';



@Injectable({
  providedIn: 'root'
})
export class SignupService {

  constructor(private http:HttpClient) { }
  GetAll() {
    return this.http.get<User[]>('http://localhost:53935/api/Signup/GetAll', { responseType: 'json' });

  }
  getUser(userEmail: string) {
    return this.http.get<User[]>('http://localhost:53935/api/Signup/GetUser?userEmail=' + userEmail, { responseType: 'json' });

  }
  getLoggedUser(userEmail:string){
    return this.http.get<User>('http://localhost:53935/api/Signup/GetUser?userEmail=' + userEmail, { responseType: 'json' }); 
  }
  // post(user:User){
  //   let httpheaders=new HttpHeaders({
  //     'Content-Type': 'application/json',
  //     'Cache-Control': 'no-cache'
  //   });
  //   let options = {
  //     headers: httpheaders
  //   };
  //   return this.http.post('http://localhost:53935/api/Signup/Post', user,options)
  // }
  Addpost(post:Post){
    let httpheaders=new HttpHeaders({
      'Content-Type': 'application/json',
      'Cache-Control': 'no-cache'
}

    );
    let options={
      headers:httpheaders
    };
    return this.http.post('http://localhost:53935/api/Posts/Addpost',post,options)
  }
  getAllPosts(){
    return this.http.get<Post[]>('http://localhost:53935/api/Posts/Getposts', { responseType: 'json' });

  }
  Details(user:details){
    let httpheaders=new HttpHeaders({
      'Content-Type': 'application/json',
      'Cache-Control': 'no-cache'
    }
    );
    let options={
      headers:httpheaders
    };
    return this.http.post('http://localhost:53935/api/Signup/details',user,options)
  }
 
  Addimage(post:Post){
    let httpheaders=new HttpHeaders({
      'Content-Type': 'application/json',
      'Cache-Control': 'no-cache'
}
    );
    let options={
      headers:httpheaders
    };
    
    return this.http.post('http://localhost:53935/api/Posts/AddImage',post, options)
  }
  incrementLike(postid:number){
    let httpHeaders = new HttpHeaders({
      'Content-Type': 'application/json',
      'Cache-Control': 'no-cache'
    });
    let options = {
      headers: httpHeaders
    };
    return this.http.put<Post>('http://localhost:53935/api/Posts/likeIncrement?postId=', +postid,options);
  }
   decrementLike(postid:number){
     let httpHeaders = new HttpHeaders({
      //  'Content-Type': 'application/json',
       'Cache-Control': 'no-cache'
     });
     let options = {
       headers: httpHeaders
     };
     return this.http.put<Post>('http://localhost:53935/api/Posts/likedecrement?postId=', +postid,options);
   }
  addComment(comment: Comments) {
    let httpHeaders = new HttpHeaders({
      'Content-Type': 'application/json',
      'Cache-Control': 'no-cache'
    });
    let options = {
      headers: httpHeaders
    };
    return this.http.post('http://localhost:53935/api/Comment/Addcomment', comment, options);
  }
  getAllComments(Postid: number) {
    return this.http.get<Comments[]>('http://localhost:53935/api/Comment?id=' + Postid, { responseType: 'json' });
  }
  image(id,imagedata){
    let httpheaders=new HttpHeaders({
      'Content-Type': 'application/json',
      'Cache-Control': 'no-cache'
    });
    // let options={
    //   headers:httpheaders
    // };
    // let body = JSON.stringify({ 'foo': 'imagedata' });
    return this.http.post<User>('http://localhost:53935/api/Signup/Image?id='+id, JSON.parse(imagedata))
  }
  profile(user:User){ let httpheaders=new HttpHeaders({
    'Content-Type': 'application/json',
    'Cache-Control': 'no-cache'
  });
  let options={
     headers:httpheaders
   };
  //  let body = JSON.stringify({ 'foo': 'imagedata' });
  return this.http.post<User>('http://localhost:53935/api/Signup/profile',user,options);
    
  }



}
