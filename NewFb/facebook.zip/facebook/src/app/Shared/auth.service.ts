import { Injectable } from '@angular/core';
import { CanDeactivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { SignupComponent } from '../signup/signup.component';

// @Injectable({
//   providedIn: 'root'
// })
// export class AuthguardService implements CanDeactivate<SignupComponent>  {

//   constructor(private router:Router) { }
//   canDeactivate(
//     component: SignupComponent,
//     route: ActivatedRouteSnapshot,
//     state: RouterStateSnapshot
//   ): boolean {
//     if(component.createform.dirty)
//    alert('you want to discard the changes')
//    else
//    this.router.navigate(["/Login"]);
//    return true;
// }
// }
