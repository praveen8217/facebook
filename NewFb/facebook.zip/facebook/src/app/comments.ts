export class Comments {
    id: number;
    Postid : number;
    contents : string;
    commentedBy: string;
    Userid:number;
    //commentedbyUserName : string;
}
