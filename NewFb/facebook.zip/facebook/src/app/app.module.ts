import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { SignupService } from './Shared/signup.service';
import { PostsComponent } from './posts/posts.component';
import { NewpostComponent } from './newpost/newpost.component';
import { ProfileComponent } from './profile/profile.component'
import { AuthService } from './Shared/authguard.service';
import { DetailsComponent } from './details/details.component';
// import { AuthguardService } from './Shared/auth.service';
import { DatePickerModule } from '@syncfusion/ej2-angular-calendars';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';





@NgModule({
  declarations: [
    AppComponent,
  
    LoginComponent,
  
    SignupComponent,
  
    PostsComponent,
  
    NewpostComponent,
  
    ProfileComponent,
  
    DetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    DatePickerModule,
    NgbModule,
  ],
  providers: [SignupService,AuthService,],
  bootstrap: [AppComponent]
})
export class AppModule { }
