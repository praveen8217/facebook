import { Component, OnInit } from '@angular/core';
import { Post } from '../post'
import { SignupService } from '../Shared/signup.service';
import { Route } from '@angular/compiler/src/core';
import { Router, ActivatedRoute } from '@angular/router';
import { post } from 'selenium-webdriver/http';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-newpost',
  templateUrl: './newpost.component.html',
  styleUrls: ['./newpost.component.css']
})
export class NewpostComponent implements OnInit {
  post: Post;
  Istext: boolean;
  userEmail: any;

  constructor(private signupservice: SignupService, private router: Router, private route: ActivatedRoute, private httpService: HttpClient, ) {
    this.post = new Post();
  }

  ngOnInit() {
    this.getData();
  }
  myFiles: any;

  formData = new FormData();
  getData() {
    this.post.postedBy = this.route.snapshot.paramMap.get("id");
    this.userEmail = this.route.snapshot.paramMap.get("Email");
  }
  getpostdetails(e) {


    this.myFiles = e.target.files[0];
    this.formData.append("fileUpload", this.myFiles);

  }
  getPostType(postType: string) {
    this.post.postType = postType;

    if (this.post.postType == "text") {
      //this.post.postType="text";
      this.Istext = true;
    }

    else if (this.post.postType == "Image")
      this.Istext = false;
  }

  submit() {
    this.post.likesCount = 0;
    if (this.post.postType == "Image") {
      this.Istext = false;
      this.httpService.post<any>('http://localhost:53935/UploadFile', this.formData).subscribe(data => {
        this.post.postContent = data;
        this.signupservice.Addpost(this.post).subscribe(
          data => {
            this.router.navigate(["/Post", this.userEmail]);
          }
        )
 })
}
    else
      this.signupservice.Addpost(this.post).subscribe(
        data => {
          this.router.navigate(["/Post", this.userEmail]);
        }
      )

  }
}
