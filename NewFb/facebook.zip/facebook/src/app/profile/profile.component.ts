import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SignupService } from '../Shared/signup.service'
import { User } from '../user';
import { HttpClient } from '@angular/common/http';
import { from } from 'rxjs';
import { Binary } from 'selenium-webdriver/firefox';


@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  userEmail: any;
  user: User;
  userImage: any;
  // comment: Comments;
  id: number;
  userName: string;
  useremail: string;
  age: number
  gender: string
  Image: Binary
  Isimage: boolean = false;
  lsatname: string;
  image: Binary[]
  Id: number;
  defaultimage:Binary;
  // userEmail:string;

  constructor(private httpService: HttpClient, private route: ActivatedRoute, private signupservice: SignupService, private router: Router) { }

  ngOnInit() {
    this.Profile();
    // this.getFileDetails(true);
  }
  myFiles: any;
  frmData = new FormData();


  getFileDetails(e) {


    this.myFiles = e.target.files[0];
    this.frmData.append("fileUpload", this.myFiles);
    this.httpService.post<any>('http://localhost:53935/UploadFiles', this.frmData).subscribe(
      data => {
        // this.Isimage = true;
        this.image = data;
        this.user.image = data;
        // this.image=this.user.image;
        this.Id = this.user.id
        this.signupservice.profile(this.user).subscribe(
          data => {
            console.log(data);
            this.Isimage = false;
            Image = data.image;
            document.location.reload(true);
          }
        )

      });
  }



  // @Input('userEmail') masterName: string;
  // user = 'userEmail';
  Profile() {
    let flag=0
    //this.userEmail = this.route.snapshot.paramMap.get("Email");
    var userEmail = localStorage.getItem('email')
    this.signupservice.getLoggedUser(userEmail).subscribe(data => {
      console.log(data)
      this.user = data;
      if (this.user.image) {
        this.userImage = this.user.image;
        this.Isimage = true;
      }
      else {
        flag=1;
        this.defaultimage=this.user.image
      }
      this.age = this.user.age;
      this.gender = this.user.gender
      this.id = this.user.id;
      this.userName = this.user.firstName
      this.userEmail = this.user.email
      this.lsatname = this.user.lsatName
    })



  }


  logOut() {
    localStorage.removeItem('email');
    this.router.navigateByUrl("/Login");
  }
}
